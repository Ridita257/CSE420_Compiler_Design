# Name:Sadia Sobhana Ridi
# ID:18301279
# Section:CSE_420 (11)

class Lexical_analyzer:
    def __init__( self ):
        # creating empty lists
        self.keywords = []
        self.identifiers = []
        self.mathops = []
        self.logicops = []
        self.numeric = []
        self.others = []
        self.lines = []
        # reading reference files 
        self.keys = []
        key_file = open( 'keyword.txt', 'r' )
        for line in key_file.readlines():
            self.keys.append( line.strip())
        self.m_ops = []
        m_file = open( 'math_ops.txt', 'r' )
        for line in m_file.readlines():
            self.m_ops.append( line.strip())
        self.logic_ops = []
        logic_file = open( 'logical_ops.txt', 'r' )
        for line in logic_file.readlines():
            self.logic_ops.append( line.strip())
            
    def read_file( self, filename ):
        # reading input file
        source = open( filename, 'r' )
        for line in source.readlines():
            line = line.strip().split()
            #print( line )
            self.lines.append( line )
        source.close()
        
    def isKeyword( self, token ):
        # checking if the token is in reference keywords
        if token in self.keys:
            return True
        
    def isIdentifier( self, token ):
        # checking if the token is an identifier
        e = token[0]
        # the first character can be either a letter or '_'
        if e.isalpha() or e == '_':
            if len(token) == 1:
                return True
            t = token[1:].split( '_' )
            flag = True
            # checking if rest of the token is alphaneumeric
            for item in t:
                if not item.isalnum():
                    flag = False
                    break
            return flag
        else:
            return False
        
    def isMathOp( self, token ):
        # checking if the token is a math operator
        if token in self.m_ops:
            return True
        
    def isLogicOp( self, token ):
        # checking if the token is a logical operator
        if token in self.logic_ops:
            return True
        
    def isNumeric( self, token ):
        # checking if the token is a numeric value
        if token.isnumeric():
            return True
        else:
            t = token.split( '.' )
            if len( t ) == 2 and t[0].isnumeric() and t[1].isnumeric():
                return True
            else:
                return False
            
    def tokenize( self ):
        # specifying tokens and storing them into designated lists
        for line in self.lines:
            for token in line:
                token = token.strip()
                # print( token,len(token) )
                if self.isKeyword( token ):
                    if token not in self.keywords:
                   # print( 'in isKeyword: ', token )
                        self.keywords.append( token )
                elif self.isIdentifier( token ):
                    if token not in self.identifiers:
                    # print( 'in isIdentifier: ', token )
                        self.identifiers.append( token )
                elif self.isMathOp( token ):
                    if token not in self.mathops:
                    # print( 'in isMathOp: ', token )
                        self.mathops.append( token )
                elif self.isLogicOp( token ):
                    if token not in self.logicops:
                    # print( 'in isLogicOp: ', token )
                        self.logicops.append( token )
                elif self.isNumeric( token ):
                    if token not in self.numeric:
                        self.numeric.append( token )
                elif token not in self.others:
                    # print( 'in Others: ', token )
                    self.others.append( token )
                    
    def print_lex( self ):
        # print outputs
        print( 'Keywords: ',self.keywords )
        print( 'Identifiers: ',self.identifiers )
        print( 'Math Operators: ',self.mathops )
        print( 'Logical Operators: ',self.logicops )
        print( 'Numerical Values: ',self.numeric )
        print( 'Others: ',self.others )
        
# main function  
if __name__ == "__main__":                
    lex = Lexical_analyzer()
    lex.read_file( 'input.txt' )
    lex.tokenize()
    lex.print_lex()