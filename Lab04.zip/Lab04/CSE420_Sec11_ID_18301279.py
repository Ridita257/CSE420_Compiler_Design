# Name:Sadia Sobhana Ridi
# ID:18301279
# Section:CSE_420 (11)
def lex(file_name):
    source = open( file_name, 'r')
    lines = source.readlines()
    returns = ['int', 'double','float','void','boolean']
    attributes = ['public','private','static']
    methods = []
    parameters = []
    return_type = []
    #print(lines)
    for line in lines:
        line = line.strip()
        parts = line.split('(')
        #print(parts)
        if len(parts)==2 and ';' not in parts[1]:
            if parts[0].split()[-2] in returns or parts[0].split()[-3] in attributes:
                f = parts[0].split()[-1]
                if f != 'main':
                    methods.append(parts[0].split()[-1])
                    parameters.append(parts[1].strip(')'))
                    return_type.append(parts[0].split()[-2])
                
    
    #print(methods)
    #print(parameters)
    print('Methods:')
    for i,m in  enumerate(methods):
        print(methods[i], '(', parameters[i], '), return type:', return_type[i])
        
lex('input_lab4.txt')

