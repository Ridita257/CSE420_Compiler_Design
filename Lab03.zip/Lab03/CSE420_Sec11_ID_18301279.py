# Name:Sadia Sobhana Ridi
# ID:18301279
# Section:CSE_420 (11)
import re
def read_file(file_name):
    regex_list = []
    word_list = []
    source = open( file_name, 'r' )
    num_of_regex = int(source.readline())
    #print(num_of_regex)
    for i in range(num_of_regex):
        regex_list.append(source.readline().strip())
    #print(regex_list)
    num_of_words = int(source.readline())
    #print(num_of_words)
    for j in range(num_of_words):
        word_list.append(source.readline().strip())
    #print(word_list)
    source.close()
    return regex_list, word_list

def main():
    regex_list, word_list = read_file('input_1.txt')
    for word in word_list:
        flag = False
        for i,regex in enumerate(regex_list):
            if re.search(regex, word):
                print('YES,',i+1)
                flag = True
                break
        if not flag:
            print('NO, 0')
main()