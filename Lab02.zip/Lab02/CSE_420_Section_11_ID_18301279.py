# Name:Sadia Sobhana Ridi
# ID:18301279
# Section:CSE_420 (11)

class DFAtoRE:
    def __init__(self):
        self.inp = []
        
    def read_file( self, filename ):
        source = open( filename, 'r' )
        lines = source.readline()
        #print(lines)
        self.inp = source.readlines()[:int(lines)]
        
    def analyze(self):
        for l,line in enumerate(self.inp):
            self.evaluate(line.strip(),l+1)
            
    def evaluate(self,line,l):
        web_flag = False
        if line[:4] == 'www.':
            web_flag = True
            for idx,ch in enumerate(line[4:]):
                if ch == '.':
                    first = line[4:idx+4]
                    last = line[idx+5:]
                    web_flag = True
                    break
                web_flag = False    
            if web_flag and len(first) != 0:
                for ch in first:
                    if ch not in 'abcdefghijklmnopqrstuvwxyz_0123456789':
                        web_flag = False
                        break
            else:
                return
                
            if web_flag:        
                for ch in last:
                    if ch not in 'abcdefghijklmnopqrstuvwxyz.':
                        web_flag = False
                        break
            if web_flag:
                print('Web,',l)
            
        
        else:
            email_flag = False
            for idx,ch in enumerate(line):
                if ch == '@':
                    first = line[:idx]
                    last = line[idx+1:]
                    email_flag = True
                    break
                email_flag = False
            if email_flag:
                for idx,ch in enumerate(first):
                    if idx == 0:
                        if ch not in 'abcdefghijklmnopqrstuvwxyz':
                            email_flag = False
                            break
                    else:
                        if ch not in 'abcdefghijklmnopqrstuvwxyz_0123456789':
                            email_flag = False
                            break
            if email_flag:        
                for ch in last:
                    if ch not in 'abcdefghijklmnopqrstuvwxyz.':
                        email_flag = False
                        break
            if email_flag:
                print('Email,',l)
             
        
        
                
                
                
            #print(ch)
        
expression = DFAtoRE()
expression.read_file('Lab02.txt')
expression.analyze()
    


                               